from enum import IntEnum


class LearningAutomataType(IntEnum):
    VASLA = 1,
    SVDHLA = 2,
    AVDHLA = 3
