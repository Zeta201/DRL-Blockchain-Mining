import enum


class Fork(enum.IntEnum):
    Irrelevant = 0,
    Relevant = 1,
    Active = 2
