import enum


class Action(enum.IntEnum):
    Adopt = 0,
    Override = 1,
    Match = 2,
    Wait = 3
