# Proof of Work Blockchain MDPs

Implementation of MDPs for double spending and selfish mining for proof of work blockchains (cf. https://doi.org/10.1145/2976749.2978341)
